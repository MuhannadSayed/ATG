export const imagesLinks = {
  //V75: require('v75.jpeg'),
};
