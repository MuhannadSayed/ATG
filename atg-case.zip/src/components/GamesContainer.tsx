import React from 'react';

import MainBetType from './MainBetType';

const GamesContainer = ({navigation}) => {
  return <MainBetType />;
};

export default GamesContainer;
